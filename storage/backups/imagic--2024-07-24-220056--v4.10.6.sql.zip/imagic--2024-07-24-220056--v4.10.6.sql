-- MySQL dump 10.13  Distrib 8.0.36, for Linux (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `ownerId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vdrvltpoyltwoprbmgkmcfkvseecwtkptuwe` (`ownerId`),
  CONSTRAINT `fk_ogedmvvdyebtwjvdorvejgtlryabezsvdjps` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vdrvltpoyltwoprbmgkmcfkvseecwtkptuwe` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_icvmaxplykyhxksaopiwgfcpsazsdidbzzjl` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_dhkalmekurzgruoqndotkgzcrdejnpnsfxhf` (`dateRead`),
  KEY `fk_qntgltieunjbjobgtifhkxscjuuuppmqzjco` (`pluginId`),
  CONSTRAINT `fk_qntgltieunjbjobgtifhkxscjuuuppmqzjco` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ydxhmvzfuxehcuoivyzsgcteffzwhpsaqtnz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tglywdlgqcomxfwqjdlayieuwzevkafchmcc` (`sessionId`,`volumeId`),
  KEY `idx_ueuedpjzcxvfoltzudaqxvwvtapapvimfudz` (`volumeId`),
  CONSTRAINT `fk_atcmlmugiahaxkrqaxmhdoinsvwwseroauwe` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_btzeutgcdzthemqztvxajoalgcnkuktxphjd` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vjxqypcyudbbfbfyhoxxjayjzlkgpzvaphqv` (`filename`,`folderId`),
  KEY `idx_rlfdxuqdbvwpbwgyklkuewyiunetfeehzkwk` (`folderId`),
  KEY `idx_rnohfpijyofzqrlwxbaskvecyusdccuvusme` (`volumeId`),
  KEY `fk_cdbbswqkkecutwvwdmgpjsxatosagaooruen` (`uploaderId`),
  CONSTRAINT `fk_assvruemqpwltbcduycowwrjbefrsczcjtlz` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cdbbswqkkecutwvwdmgpjsxatosagaooruen` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dxkgujdlvxqrjwbjbjgudrickmklkzbizdtj` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qijzjmujleukafvvxropwapywkgsxfwjpzsk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_csfbwpsbjagqtzckvpzweseexuxgvhkbklpp` (`groupId`),
  KEY `fk_djjcclklolryodhrxgldtxdfsfmcuppehwzu` (`parentId`),
  CONSTRAINT `fk_djjcclklolryodhrxgldtxdfsfmcuppehwzu` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ltpegqalsmnkptzobwievothduemjvrvcrgq` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ntffgxuaccjswxvyqygdfhpwzjsgjehjxagp` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dhlbwbzowwtmihlxuohtmwuzhpihaidqzvec` (`name`),
  KEY `idx_pudxqwfclfmmmokzdsqdlijhpnnoptksirfi` (`handle`),
  KEY `idx_lqatakvvwzyiajznoxpgabubvbpdtqlslbpw` (`structureId`),
  KEY `idx_mqzkulksgwkqpxqyzgeafckrvgzqdoohxyrw` (`fieldLayoutId`),
  KEY `idx_dhzxxltumtdneecdxbkkqwtjvfcqrqtchwwm` (`dateDeleted`),
  CONSTRAINT `fk_bznagzacfcrggdrjiofxlgyxixotbrkcmatx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lauwoszwxhziznayewfaeqxezqtcgrkitwqv` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rvlearfecmpgmfbupactuscezlfcwtvjqeju` (`groupId`,`siteId`),
  KEY `idx_wkhdfdikttczdfqgknzxmtuqdzxzbrfkrfmo` (`siteId`),
  CONSTRAINT `fk_ebwsfoexzqmtkvbgrkaopbxosrxitnteolvy` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kmfjdilivluuuvlfbdmljzmbptvxmixyjraw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_ersyabjgayvyntlbykykjsexfqflfhzwmoid` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_eskgiiivqqrbyzcchnytjsbdhldfnygdivmz` (`siteId`),
  KEY `fk_tlvauirqhnbdcfcstxkpumppputhmrpsicbg` (`userId`),
  CONSTRAINT `fk_eskgiiivqqrbyzcchnytjsbdhldfnygdivmz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tlvauirqhnbdcfcstxkpumppputhmrpsicbg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tmzyfnpxrgbtfwrxjoivdbllvaztnydrtkfi` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_sgtyppotcmtjxiziksskbwdzuxgoycgyycid` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_cmfefmlmfcuoafdkctphcwxvqnpvsxiznhmw` (`siteId`),
  KEY `fk_yiebiiopqfyavmauioxdndotgyfvlqafexcf` (`fieldId`),
  KEY `fk_drxjzkvwbykhqamlnjzgwlgadldsdcwstour` (`userId`),
  CONSTRAINT `fk_cmfefmlmfcuoafdkctphcwxvqnpvsxiznhmw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_drxjzkvwbykhqamlnjzgwlgadldsdcwstour` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_iwzobyqkcmjrsmzhoqxhaubsqpcodlvuwlbn` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_yiebiiopqfyavmauioxdndotgyfvlqafexcf` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_heroTitle_ewyrbvdc` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ouughioctyciumfcxfdxjpbafcdqzynpxgbd` (`elementId`,`siteId`),
  KEY `idx_lclryosygbmgtzvhzbprhwkmniakimkovlct` (`siteId`),
  KEY `idx_tpvifudzfjpbtmpusyqwbebgwpwwxzujphvp` (`title`),
  CONSTRAINT `fk_ajkonfwlcdtrljnucgztuobbswuvibskrdho` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mvufixmilwzahuoisqjwnxakdagtaclesnuy` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_cxzxrqqtqvalbylahaidhzdhlbdfqjvztiyu` (`userId`),
  CONSTRAINT `fk_cxzxrqqtqvalbylahaidhzdhlbdfqjvztiyu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ilmaarjqbbgutxgipdgjbhcvbtekktutoday` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_ilodfyvdsdrfhruvhpmpcntfzhbsngkbdfnc` (`creatorId`,`provisional`),
  KEY `idx_gqmgvzsjeplxydazlomtweszebxrlntmubva` (`saved`),
  KEY `fk_fznglozagkqrjfyadyrqcskttnyyvieboxan` (`canonicalId`),
  CONSTRAINT `fk_fznglozagkqrjfyadyrqcskttnyyvieboxan` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ncbwfdakqahrcljqwyjqtkqigfqknabflraf` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_hbfajipjyrsdflareitqficepprangvwiiby` (`elementId`,`timestamp`,`userId`),
  KEY `fk_rwdziuxbmrmmszdxoauhljkellpucfghhqne` (`userId`),
  KEY `fk_jceujhhocxtpzwpzrnrjdwyaldnwobswppxu` (`siteId`),
  KEY `fk_xqadindsewwktxrzhadkymbtwujhcnlcgtin` (`draftId`),
  CONSTRAINT `fk_jceujhhocxtpzwpzrnrjdwyaldnwobswppxu` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oitstyqseabwnvluuwzikjcybbnshrcqymry` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rwdziuxbmrmmszdxoauhljkellpucfghhqne` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xqadindsewwktxrzhadkymbtwujhcnlcgtin` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lvcxxuybjztsukbrujuaunuhvwvolhjkwsaq` (`dateDeleted`),
  KEY `idx_jtgqfznjpuhtmepwjcqducgeedyewazyzemi` (`fieldLayoutId`),
  KEY `idx_cdaxyaqabqodryfqatjjwsrkmjlxsvjrbwaq` (`type`),
  KEY `idx_poxfcbouwzesdetxofdgylfuiehfhcmkpssc` (`enabled`),
  KEY `idx_zfdzxsojunuxtbqdwocdwpedflkhooougfpz` (`canonicalId`),
  KEY `idx_tsjksrvsuqylqajyvbtqtouuuqvfkemaiiwm` (`archived`,`dateCreated`),
  KEY `idx_ddlzlcowyitgrhpjxzkefjrivwvjjyehfktu` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_voaywzsqingecmcvdrneetvpscrhlqczroam` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_mhaahugwsfewyispyqcykylkijtavhhbydao` (`draftId`),
  KEY `fk_wvmsspqiavxlcanmohgqjcwvdmifsrgulnin` (`revisionId`),
  CONSTRAINT `fk_epqxzfzqcudazusdwpbuxxtfphdgwggtvpqn` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mhaahugwsfewyispyqcykylkijtavhhbydao` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nftqlgsytglricueptjwjxifrezmmhvetghq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wvmsspqiavxlcanmohgqjcwvdmifsrgulnin` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fichaaqloshvmcdxydvjuuwuuyzranzkwrsd` (`elementId`,`siteId`),
  KEY `idx_kgrnpanfptqwqjbnjlozlimanjzgovzzwanl` (`siteId`),
  KEY `idx_udklufrmyvnaojcxpgayfjwvruhvjwonwsas` (`slug`,`siteId`),
  KEY `idx_xlrpknxnpwlkqzwfiwvmainnsiwbxdhsxhnb` (`enabled`),
  KEY `idx_vkslukiwqwdwkhbemnazqkfxxxjoryuwupta` (`uri`,`siteId`),
  CONSTRAINT `fk_qgjbxqcwqkyrysrihukkwhofjeqdtdvnqyhy` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sfkbfizgflplolxtlywgweljjysfboudachq` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_szepynzlqrzqmofhgwaiavvtgrizkllnaoiy` (`postDate`),
  KEY `idx_uabphajdqbsgwmnmdrxenjsfadeflwxawytw` (`expiryDate`),
  KEY `idx_hajamwzsiwigvifvecmqfleuzlmnywvgjdpn` (`authorId`),
  KEY `idx_fzunmltlqmrgccsmleoclybewkrwyynahclb` (`sectionId`),
  KEY `idx_yopyvrnxphixzakhtczvnjqgwdzkgbulgpxm` (`typeId`),
  KEY `fk_idbwliyynojrdgtpmdllbezsbrmauqrpftzo` (`parentId`),
  CONSTRAINT `fk_hfaqkxeixyeqdqwyqijbnhlvxomiuqmerqgx` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_idbwliyynojrdgtpmdllbezsbrmauqrpftzo` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tbmctuahadnirchekocsdwguphvdbsvjvmdg` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_upvbvtjvcfujnmbjlratgjcxepqyueysdzqq` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vxobnqitobepqldzxeyrzbzgbnpkamaxygzq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_duzlxjomequfohntiqozaxqdgiidlnzojyea` (`name`,`sectionId`),
  KEY `idx_abtehxdfglhjrlwexezhpahltmgxpkkzfgkw` (`handle`,`sectionId`),
  KEY `idx_ysrdoaurspbhuuqowzennzosxwdzzibehaec` (`sectionId`),
  KEY `idx_vilfawriayuzvajbabbrzbfuxctvcllgemwz` (`fieldLayoutId`),
  KEY `idx_uiqmudkqwkpwchpsqdpcovbfdqgpytobqwdi` (`dateDeleted`),
  CONSTRAINT `fk_mwehixyfqdclkwkeehsttgwejoeugitopfsa` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zuwauxegyiqkubiulicnbxxhercfnolgsclz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fvxjqekuudxqmpoesrclygzfdqqtadkzuuyk` (`name`),
  KEY `idx_eqspllsazbjvbntcbfsfcuscemmnplpgtloi` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `tabId` int NOT NULL,
  `fieldId` int NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vlmhecgyhsyiupinldqpizhgvznhpgullmrx` (`layoutId`,`fieldId`),
  KEY `idx_abmhavhrdpgrwniqetsfxeoieusqhmtzsttf` (`sortOrder`),
  KEY `idx_uarugwzmcxtudrewtcbzpqalpivzewpneqgj` (`tabId`),
  KEY `idx_edubrvyryjqgzbqxqocaaeqpkrgzmaopzluo` (`fieldId`),
  CONSTRAINT `fk_gyjwlmbacsnpsjelqnspnwqoquknqyihbywt` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ncaschrtckwmcfoydgutaspndvqvursgbkbj` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uakylhhjzpmizowogiuafrxbvtkmuzduiulx` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_imhecfphaoknlalcmfiassnbvzzzhjgajkkh` (`dateDeleted`),
  KEY `idx_jtgtivwdkjamkdquirkomwgiirpwnxcbhnvr` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text,
  `elements` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hehncmgstmbgajfpjkrkkovgeqmpqspkzais` (`sortOrder`),
  KEY `idx_sitbjmoeptrendbtmdmjyogwbfiqsvwkywod` (`layoutId`),
  CONSTRAINT `fk_brvxdyjsiccthypnkksadeidlyhjxizjnyaw` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vduukkbwwiawuoquhmxucuvmqaawckrnrxsi` (`handle`,`context`),
  KEY `idx_sjrpcrehsdduwrsefjnhkyhrwjqpagpwkxli` (`groupId`),
  KEY `idx_abzivylzhokeydssikuqenoplaormnjustsa` (`context`),
  CONSTRAINT `fk_hjwuhcoezivwhsalvgcpfmwjrjvgpcbtkxnn` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ncrckqpwfjtczhjhvtqysdibgiitinysruqg` (`name`),
  KEY `idx_pqahuhpzocsajfnkokbzimhydjxpajoyemre` (`handle`),
  KEY `idx_fystiawxkatrzkasijmcnghbevhqiljtryhy` (`fieldLayoutId`),
  KEY `idx_xkjebdsokgupfkdtcvsfpdpwbrlsrjuzmgmv` (`sortOrder`),
  CONSTRAINT `fk_xoimavmhfpoyfygdfweccwtbmxmxwehetxfr` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xubwomxlvkjfhboosguvprtsrxbrgsfdpcdg` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kgxyswsoeuzcyrmnaxsdkbfpiqsgvsoupflb` (`accessToken`),
  UNIQUE KEY `idx_pdiwkkpvudakaegluwtzblagdvjbzrqtqili` (`name`),
  KEY `fk_knsvgltmdtidsnxfdlrsbqpwepxaraixbkys` (`schemaId`),
  CONSTRAINT `fk_knsvgltmdtidsnxfdlrsbqpwepxaraixbkys` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ezslbctdrmmfqdsophmwlcrsghcculkwvhof` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lfeqbcaklwyuwqrouamfodhklatoileywmkz` (`name`),
  KEY `idx_twvbiriovswqlcpksmhzdnccsopncyvdmgac` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_eaesqapbyhptoxbqpdxwosugdubzilyzqjey` (`primaryOwnerId`),
  KEY `idx_rkjfmxdzgqxnqeckoqxrhaehllktqqfuhjsr` (`fieldId`),
  KEY `idx_iqmusuzaitaioyztlqkktxwlyxoaydvqiedo` (`typeId`),
  CONSTRAINT `fk_csxufchcpxjrcuzoedeynskgxfhvqphalfpg` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_flrkmbwpeilmszujaysbypsyeuxbljabzpno` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ftmmsqtperpowzrdwvpltnvynohsmxqdcfqx` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hyqorgtwrpsvzfjhhnencaailfhrewtpzezs` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_nybzyqqaukftarfwbohtdxvcfufzurvmplzl` (`ownerId`),
  CONSTRAINT `fk_nybzyqqaukftarfwbohtdxvcfufzurvmplzl` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uowzkjluqruamqdfrnrbrowdvpwjjgziglcy` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vwgzpsqouecwgjwojyjdlgswhwgustbgdecf` (`name`,`fieldId`),
  KEY `idx_udfyurzpfxsvlqdxmveihhmaszqzbtxsntpf` (`handle`,`fieldId`),
  KEY `idx_suyeclnmtgkyviliwjmxcjuikgpchrvrwcvw` (`fieldId`),
  KEY `idx_ybwfvyaibqshjobzmtcoevwvhwuspyfuwuog` (`fieldLayoutId`),
  CONSTRAINT `fk_dchdhcydmbjuwltlmdpdzuiduzijtfcqzwiq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wwhoahjkovuussaufmlitfgtcbjugaktnjwc` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qvtrcnxfokhvzfokoynwrtssikbhqltvzepc` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ilqnvnlvlepodexsecboerocdtypksiosbne` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_zxhmzatlsjtapulhlkiqvvxqtfltagmbekmb` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_zcypmuswotthpvqslmupybkrdtzaijqyepgg` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tghvzyrcccammcfbaxfwiuzgbblqwitwathc` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_hodqmlpuzmzulkhxxnpbjiquvscyuobihtvx` (`sourceId`),
  KEY `idx_ubvfnrxvzzsqikynpcgnhpjmczitibgsegvn` (`targetId`),
  KEY `idx_crjnnspwsxwmzkdgdmntofajgvspbbthehra` (`sourceSiteId`),
  CONSTRAINT `fk_gixxvmleuwbovasgingjctubmgtfqugfvquu` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_utthkuorcbjxxvvbohybmzslsjsvglrqxigz` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xbuzpjculomgmkolbqkygmsxgxezuicexpyx` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kmgnwihtkxibzzscoabkcoopnxtfcxmepeqn` (`canonicalId`,`num`),
  KEY `fk_gdckatougcknmrhvqpsvvpijcrxdvpjkqvpt` (`creatorId`),
  CONSTRAINT `fk_gdckatougcknmrhvqpsvvpijcrxdvpjkqvpt` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vrqjxioxncqsjwnjnicxuhswdtmpoiqxgrfz` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_uahwnaqdnvqzoqnirrndjmnmqorwcfcydetb` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ahgrygglxhkoxxgihuqozmfcmnleojnglzxd` (`handle`),
  KEY `idx_tfrriyaqukiyzywzsdoopjzdpdgjcirbukhs` (`name`),
  KEY `idx_pcnuxysfvrylqsautrlityjyxnblrhmucuvi` (`structureId`),
  KEY `idx_edpfkcaqmxedgmjqwkxxkbojqmekhpjqwrti` (`dateDeleted`),
  CONSTRAINT `fk_nkrtejjlvinsmznkdzmchcrzpxnjpcxswrqq` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uspuwgidnfomnyeiqiveyjwembzzdgvizotb` (`sectionId`,`siteId`),
  KEY `idx_vbfhahvotyltrxoovplpjaljpsgvnrezmvvp` (`siteId`),
  CONSTRAINT `fk_femmnjpisymgzqfxsrtkotfqohcdhtsufkim` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xvkjhvahogmbbdwbgloprppweopvmrztqmke` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_flzbllvfkjssezeawwrmmbymcvltkgjopqct` (`uid`),
  KEY `idx_xtscudamwhwkaxdonwtjtgutetglfcnprekd` (`token`),
  KEY `idx_fwpklfvagjjpportqdyifcjhtuvgexsruxgl` (`dateUpdated`),
  KEY `idx_zmgfkrxcfyzelvbjigqjphlfpkicekxczjao` (`userId`),
  CONSTRAINT `fk_rojoepqkiozxqhkeksqigqaiuooisbgcfawu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tmvkermnqlhgffxzjbzrdsjhnxrincxpmtby` (`userId`,`message`),
  CONSTRAINT `fk_nksxfztogjwsjwvaexhciogzyqoayapsvcrg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mtmjixhknriyvfrgruehtfzbwkysvegsvcff` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jwabzcbjkmwfcnixcnuicafoklojujbwxnqt` (`dateDeleted`),
  KEY `idx_ldzedyvluiywmlmmndqnvnyjpuponcmzosna` (`handle`),
  KEY `idx_aypxszucnywriggcvcmkyvmfeiurjohebske` (`sortOrder`),
  KEY `fk_aqrfhfaaekntwqdbzvqtxnwgxwaeavbraphb` (`groupId`),
  CONSTRAINT `fk_aqrfhfaaekntwqdbzvqtxnwgxwaeavbraphb` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zbimirykfpmflhujfuwnvnunshuvplbsxbsl` (`structureId`,`elementId`),
  KEY `idx_gbhlvmxerdlkmpjdylbtgekluwihqyomfzji` (`root`),
  KEY `idx_hzgduvnrfawynrkhhawpfwsackuhhkdhzosh` (`lft`),
  KEY `idx_zelvtpqiyyoqexhdmkvxhrzjgstaxxnukjuu` (`rgt`),
  KEY `idx_iaazzicpcgxbbmdzlxiakwiqeghgbzquaizt` (`level`),
  KEY `idx_yptdfiezqnhaxjhsrhgzrtqafphrkjmiqvrj` (`elementId`),
  CONSTRAINT `fk_pipilxxmmkclpeonqbmikiasgfgpqztloqud` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eoybdqqbvuggosdofidptrjjbsqgfhibufuu` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lexecaolocgxgmfgnkliuvnltcasidbshgre` (`key`,`language`),
  KEY `idx_stwffkzjheplftmsvomlnyvksgibxbaqxzon` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dafkcrwepwylkrofjmoohzcglzfccbkpkpil` (`name`),
  KEY `idx_vnifialluurldtdfywwepdzfmeeazdxjicla` (`handle`),
  KEY `idx_rbyrybcdewyvwiqvmxtjpjtwzhwhwvmzgpaj` (`dateDeleted`),
  KEY `fk_tisrpjukhmlyboxspxcdibzwhjgmuzcyhnsl` (`fieldLayoutId`),
  CONSTRAINT `fk_tisrpjukhmlyboxspxcdibzwhjgmuzcyhnsl` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dmtdeidhaxpkrpghhlzpktdxjhxpniobnxvt` (`groupId`),
  CONSTRAINT `fk_xnrodjtaeccacnmpgytdgowwkczeppchrmpz` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yaostxkwlorzqoiiqgsltykcowmtzwpyhqdi` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ztaqqrerpvdesbhuvemmxfonncflrdxgdgua` (`token`),
  KEY `idx_kawvwbhgkxweszzohpzzdetmhcsufamavylq` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_agfeqnxvggffxkumcsgxcjdvsaietgyooubd` (`handle`),
  KEY `idx_yjmwinuyqketvrhcapktdrlglpvhkpiatcmr` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bdgxivwmhvmmouppitkisvnklwefwiibsfbb` (`groupId`,`userId`),
  KEY `idx_lhdmxsezvfdzbbsunnphdiacudpvzjdfhecg` (`userId`),
  CONSTRAINT `fk_npsppvocvpfaljzdifvojqcrbqmkmkhckjrx` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tkjylslpvmfcrmonxzkzretoioihusvmamzw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hieuxnlmumtdxmxgzktytqzfpwhldfwyrhxy` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aoagvupbaitntadhuawzxyqauaqcyetowzhx` (`permissionId`,`groupId`),
  KEY `idx_atktzhegcchfekqesfltbeqdljoeuldtnzmm` (`groupId`),
  CONSTRAINT `fk_ffgnniouvyttcmzywcmbshpoknrxybkqsyfs` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_humminkdutuqqxeqxzcpmkrwlqyckuwdtmpu` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rngeayjkaexssjftcihsrxtsrihjcyzgddfp` (`permissionId`,`userId`),
  KEY `idx_rbggxrcyyombvkcidvyxtpuzxcrvgwpzblfb` (`userId`),
  CONSTRAINT `fk_jfczgajkqcmvhqfsqusyhsjsnolvgporqxwk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sxaqlrrfgjnqejdxdrpbwhwmnhfekxuuglci` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_dcdbmyaetdmhkeajjjgnqctklbopwanuzirx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_njhlnjlxwqjyrvtzmvzhsxxoqmjoflhkkwsy` (`active`),
  KEY `idx_apyibfsmorrxddltldgouweuqgufzniyysqo` (`locked`),
  KEY `idx_yaizbxhcqmtkslqqzoknqumycpxxqshdashv` (`pending`),
  KEY `idx_jylkdbfcluhiegpewqbwrshbvkknvlreenqi` (`suspended`),
  KEY `idx_hlowpabnosowvgtclanchdiweavzpmfcromd` (`verificationCode`),
  KEY `idx_eqsjabqpbnloqfjecujymrfuofygttfdrtuo` (`email`),
  KEY `idx_dvwotxpwruiwuhrebjkgsojhmkigknfvysjt` (`username`),
  KEY `fk_fgqxmbnumnhqggmplincobiabdapvghyqcmh` (`photoId`),
  CONSTRAINT `fk_amdwacnfesvqkoboopyrgusiawuliselnumx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fgqxmbnumnhqggmplincobiabdapvghyqcmh` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bggqbtwxrfktoondlefjsprczfygwzjgiaae` (`name`,`parentId`,`volumeId`),
  KEY `idx_zbhalqiquncrejxfaqmcawwobsftqlxtxkyo` (`parentId`),
  KEY `idx_rxumyiudbwrznaeogpdukogahfgtbvijruhb` (`volumeId`),
  CONSTRAINT `fk_iesvyjktqldluzxopnnujyvzdclcwazawsfl` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zmrhiyuhgiizdexrvtpxerapnnwfoqgfzjjw` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_omeuznvunnlidvqywdginucloflvjlzwcvbh` (`name`),
  KEY `idx_knqeunytyfjufzekquhjqkwxgypfbqylhksd` (`handle`),
  KEY `idx_lxhxeidzhomyjcewxclesczosnybpmopigmd` (`fieldLayoutId`),
  KEY `idx_dntxzvxtysdixdwwoalzwiidocavxivnlyea` (`dateDeleted`),
  CONSTRAINT `fk_inejyqyicyomhmrtperfjyfxdbjyftcihlng` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_luausbltnlmvxzqctldjmapexzeexejyzbpv` (`userId`),
  CONSTRAINT `fk_joybwjkahfipsnrekltybvdfkoydfwasptrq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-24 22:00:56
-- MySQL dump 10.13  Distrib 8.0.36, for Linux (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (10,1,1,1,'1.png','image',NULL,683,384,457639,NULL,NULL,NULL,'2024-07-24 20:56:17','2024-07-24 20:56:17','2024-07-24 20:56:17'),(11,1,1,1,'2.png','image',NULL,683,384,383348,NULL,NULL,NULL,'2024-07-24 20:56:17','2024-07-24 20:56:17','2024-07-24 20:56:17'),(12,1,1,1,'3.png','image',NULL,683,384,467565,NULL,NULL,NULL,'2024-07-24 20:56:17','2024-07-24 20:56:17','2024-07-24 20:56:17'),(13,1,1,1,'4.png','image',NULL,683,384,454217,NULL,NULL,NULL,'2024-07-24 20:56:17','2024-07-24 20:56:17','2024-07-24 20:56:17'),(14,1,1,1,'5.png','image',NULL,683,384,275266,NULL,NULL,NULL,'2024-07-24 20:56:17','2024-07-24 20:56:17','2024-07-24 20:56:17'),(15,1,1,1,'6.png','image',NULL,683,384,5536,NULL,NULL,NULL,'2024-07-24 20:56:17','2024-07-24 20:56:17','2024-07-24 20:56:17'),(18,1,1,1,'5_2024-07-24-205753_hmyk.png','image',NULL,683,384,275266,NULL,NULL,NULL,'2024-07-24 20:57:53','2024-07-24 20:57:53','2024-07-24 20:57:53');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES (1,1,'fullName','2024-07-24 21:59:02',0,1),(1,1,'lastPasswordChangeDate','2024-07-24 21:59:02',0,1),(1,1,'password','2024-07-24 21:59:02',0,1),(3,1,'postDate','2024-07-24 20:46:06',0,1),(3,1,'slug','2024-07-24 20:46:05',0,1),(3,1,'title','2024-07-24 20:46:05',0,1),(3,1,'uri','2024-07-24 20:46:05',0,1),(6,1,'enabled','2024-07-24 20:55:59',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (6,1,2,'2024-07-24 20:57:59',0,1),(6,1,6,'2024-07-24 20:57:59',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,NULL,'2024-07-24 05:13:50','2024-07-24 21:59:02','ea9d24ef-6edd-494f-87db-1deff80e9104',NULL),(2,2,1,NULL,'2024-07-24 20:27:34','2024-07-24 20:27:34','fdd09cc9-05be-4df9-ac7e-2641df088f87',NULL),(3,3,1,'TESTing entry','2024-07-24 20:45:55','2024-07-24 20:46:06','aec70a8b-48c5-4962-a8e5-3aac66356049',NULL),(4,4,1,'TESTing entry','2024-07-24 20:46:06','2024-07-24 20:46:06','372b5c98-a976-43de-a417-68ed800824c4',NULL),(5,5,1,NULL,'2024-07-24 20:53:46','2024-07-24 20:53:46','01972c18-6c69-4abf-88e7-a62c22e48670',NULL),(6,6,1,'Home','2024-07-24 20:54:09','2024-07-24 20:57:59','625d296d-dcfa-4f99-86d1-6420550a91b8','This is the home page'),(7,7,1,'Home','2024-07-24 20:54:09','2024-07-24 20:54:09','6f137d7a-d52c-4edb-a154-0e95790a6edd',NULL),(8,8,1,'Home','2024-07-24 20:54:37','2024-07-24 20:54:37','e208b4ba-8956-4468-909f-be2d65dc8de0',NULL),(9,9,1,'Home','2024-07-24 20:55:59','2024-07-24 20:55:59','c9026919-67c0-4dc8-b4d0-ace43095de76',NULL),(10,10,1,'1','2024-07-24 20:56:17','2024-07-24 20:56:17','b0a0c915-d8d3-420e-925e-8bf92b94856d',NULL),(11,11,1,'2','2024-07-24 20:56:17','2024-07-24 20:56:17','557640ff-c83c-46e1-8d3c-33604e4540b8',NULL),(12,12,1,'3','2024-07-24 20:56:17','2024-07-24 20:56:17','e060017c-ba96-4980-8646-c15fe799a137',NULL),(13,13,1,'4','2024-07-24 20:56:17','2024-07-24 20:56:17','69af39c9-3324-4a09-92bf-97a1776e722e',NULL),(14,14,1,'5','2024-07-24 20:56:17','2024-07-24 20:56:17','cffb5a4a-a494-4a5f-a1db-a689f1236d3a',NULL),(15,15,1,'6','2024-07-24 20:56:17','2024-07-24 20:56:17','9c0ec935-6f64-4029-8583-5ee6090f6099',NULL),(16,16,1,'Home','2024-07-24 20:57:13','2024-07-24 20:57:13','9579ede7-3d4c-4326-9dc6-817b874c673f',NULL),(18,18,1,'5','2024-07-24 20:57:53','2024-07-24 20:57:53','a3c7e9ac-87a1-454b-a787-76d2d21285e0',NULL),(19,19,1,'Home','2024-07-24 20:57:59','2024-07-24 20:57:59','9dc70408-4dc7-425b-bed0-392c2231809e','This is the home page');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES (1,NULL,1,0,'First draft',NULL,0,NULL,0),(3,NULL,1,0,'First draft',NULL,0,NULL,0);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES (3,1,1,NULL,'save','2024-07-24 20:46:06'),(6,1,1,NULL,'edit','2024-07-24 20:57:53'),(6,1,1,NULL,'save','2024-07-24 20:57:59');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-07-24 05:13:50','2024-07-24 21:59:02',NULL,NULL,'b93a4210-7ca9-438e-bf0e-2436b49697d9'),(2,NULL,1,NULL,1,'craft\\elements\\Entry',1,0,'2024-07-24 20:27:34','2024-07-24 20:27:34',NULL,'2024-07-24 20:53:59','bb6306b2-dd0b-43e1-a0e8-b27ca11a982f'),(3,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-07-24 20:45:55','2024-07-24 20:46:06',NULL,'2024-07-24 20:47:54','461c2380-de6b-4ad9-b396-e0a7ec8dff3b'),(4,3,NULL,1,1,'craft\\elements\\Entry',1,0,'2024-07-24 20:46:06','2024-07-24 20:46:06',NULL,'2024-07-24 20:47:54','82aa43b7-6649-4224-8a4c-eb7f8ba5e0b3'),(5,NULL,3,NULL,1,'craft\\elements\\Entry',1,0,'2024-07-24 20:53:46','2024-07-24 20:53:46',NULL,'2024-07-24 20:53:59','7bf77201-ee7c-48f1-9f68-25ee03b2e8c3'),(6,NULL,NULL,NULL,4,'craft\\elements\\Entry',0,0,'2024-07-24 20:54:09','2024-07-24 20:57:59',NULL,NULL,'de16bf41-98a3-4370-adcb-d6f13b464ec7'),(7,6,NULL,2,4,'craft\\elements\\Entry',1,0,'2024-07-24 20:54:09','2024-07-24 20:54:09',NULL,NULL,'588355e0-80e6-4b6e-b17b-ffa1c5f71534'),(8,6,NULL,3,4,'craft\\elements\\Entry',1,0,'2024-07-24 20:54:37','2024-07-24 20:54:37',NULL,NULL,'dcb081f9-d234-4075-952e-472ca6fc1917'),(9,6,NULL,4,4,'craft\\elements\\Entry',0,0,'2024-07-24 20:55:59','2024-07-24 20:55:59',NULL,NULL,'3ab26d3a-6d0c-49a7-adc8-bad333a11f5c'),(10,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-07-24 20:56:17','2024-07-24 20:56:17',NULL,NULL,'10886a56-37e8-41d7-bc36-6cda8ef2c37c'),(11,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-07-24 20:56:17','2024-07-24 20:56:17',NULL,NULL,'24283e5c-e32e-45df-9c3f-c08109a488f7'),(12,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-07-24 20:56:17','2024-07-24 20:56:17',NULL,NULL,'638e14f3-4502-4af6-8e11-abdee2ac4214'),(13,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-07-24 20:56:17','2024-07-24 20:56:17',NULL,NULL,'46e81cfe-5dc2-41ce-b913-66818bea394b'),(14,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-07-24 20:56:17','2024-07-24 20:56:17',NULL,NULL,'3ef030c0-3422-4b45-b45d-fdc61e2e244c'),(15,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-07-24 20:56:17','2024-07-24 20:56:17',NULL,NULL,'3321cc32-3421-4448-934e-ca9d24ec83b1'),(16,6,NULL,5,4,'craft\\elements\\Entry',0,0,'2024-07-24 20:57:13','2024-07-24 20:57:13',NULL,NULL,'dd447a97-1689-4f08-b1d1-fa6889d86b9b'),(18,NULL,NULL,NULL,3,'craft\\elements\\Asset',1,0,'2024-07-24 20:57:53','2024-07-24 20:57:53',NULL,NULL,'f8ff41a9-af50-4139-9e88-5d3e2f5f79e0'),(19,6,NULL,6,4,'craft\\elements\\Entry',0,0,'2024-07-24 20:57:59','2024-07-24 20:57:59',NULL,NULL,'dfccd7f6-a699-41ed-b20f-5ae5bf7fc4a6');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2024-07-24 05:13:50','2024-07-24 05:13:50','b38cd6ed-d8f4-4b50-8e99-b6478275add2'),(2,2,1,'__temp_tabsfwacerswtwyzvqwotnjtdvmtfknjxncy','slider/__temp_tabsfwacerswtwyzvqwotnjtdvmtfknjxncy',1,'2024-07-24 20:27:34','2024-07-24 20:27:34','24f055b3-1fd7-4d24-afbf-60c87927b12b'),(3,3,1,'testing-entry','slider/testing-entry',1,'2024-07-24 20:45:55','2024-07-24 20:46:05','c50143b2-c30b-43da-8a41-6a19d0135802'),(4,4,1,'testing-entry','slider/testing-entry',1,'2024-07-24 20:46:06','2024-07-24 20:46:06','c823224d-9bc8-452c-ae1c-0c3789810a7c'),(5,5,1,'__temp_ggyieyvfaldcxfdxqttmmawgteqxukjjlqcq','slider/__temp_ggyieyvfaldcxfdxqttmmawgteqxukjjlqcq',1,'2024-07-24 20:53:46','2024-07-24 20:53:46','4ccfa877-daa8-45d1-8f97-4d3d3becacd1'),(6,6,1,'home','home',1,'2024-07-24 20:54:09','2024-07-24 20:54:09','06e0bf5d-d4ac-4fdd-83b3-117bb1752306'),(7,7,1,'home','home',1,'2024-07-24 20:54:09','2024-07-24 20:54:09','d40bcf18-c467-4ce4-a247-58382d297a0b'),(8,8,1,'home','home',1,'2024-07-24 20:54:37','2024-07-24 20:54:37','8ffe28bc-9585-4c56-9f63-3daf5a0ec8de'),(9,9,1,'home','home',1,'2024-07-24 20:55:59','2024-07-24 20:55:59','d138387d-7631-4879-9fbe-6089f97f0e36'),(10,10,1,NULL,NULL,1,'2024-07-24 20:56:17','2024-07-24 20:56:17','8949d75c-0c13-443b-ae9c-36e6ac1747da'),(11,11,1,NULL,NULL,1,'2024-07-24 20:56:17','2024-07-24 20:56:17','838ec8e1-f9fc-410d-8b9a-c96fcc417bc5'),(12,12,1,NULL,NULL,1,'2024-07-24 20:56:17','2024-07-24 20:56:17','36eb7330-86e6-4d85-a765-10630bd5a96e'),(13,13,1,NULL,NULL,1,'2024-07-24 20:56:17','2024-07-24 20:56:17','817b3be5-58f7-47a1-b10b-af253955af5c'),(14,14,1,NULL,NULL,1,'2024-07-24 20:56:17','2024-07-24 20:56:17','5fc767b9-33d2-4541-894f-5842c27edaad'),(15,15,1,NULL,NULL,1,'2024-07-24 20:56:17','2024-07-24 20:56:17','61d44280-6340-4fc0-b065-6995ce6e4daf'),(16,16,1,'home','home',1,'2024-07-24 20:57:13','2024-07-24 20:57:13','208d92ff-5ed2-4924-b38a-950c21e17f29'),(18,18,1,NULL,NULL,1,'2024-07-24 20:57:53','2024-07-24 20:57:53','f305025b-2d51-49d9-acf6-e3116f63ce74'),(19,19,1,'home','home',1,'2024-07-24 20:57:59','2024-07-24 20:57:59','1e060955-82c1-439a-9cfe-46bd0025135a');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (2,1,NULL,1,1,'2024-07-24 20:27:34',NULL,1,'2024-07-24 20:27:34','2024-07-24 20:27:34'),(3,1,NULL,1,1,'2024-07-24 20:46:00',NULL,0,'2024-07-24 20:45:55','2024-07-24 20:46:06'),(4,1,NULL,1,1,'2024-07-24 20:46:00',NULL,NULL,'2024-07-24 20:46:06','2024-07-24 20:46:06'),(5,1,NULL,1,1,'2024-07-24 20:53:46',NULL,1,'2024-07-24 20:53:46','2024-07-24 20:53:46'),(6,2,NULL,2,NULL,'2024-07-24 20:54:00',NULL,NULL,'2024-07-24 20:54:09','2024-07-24 20:54:09'),(7,2,NULL,2,NULL,'2024-07-24 20:54:00',NULL,NULL,'2024-07-24 20:54:09','2024-07-24 20:54:09'),(8,2,NULL,2,NULL,'2024-07-24 20:54:00',NULL,NULL,'2024-07-24 20:54:37','2024-07-24 20:54:37'),(9,2,NULL,2,NULL,'2024-07-24 20:54:00',NULL,NULL,'2024-07-24 20:55:59','2024-07-24 20:55:59'),(16,2,NULL,2,NULL,'2024-07-24 20:54:00',NULL,NULL,'2024-07-24 20:57:13','2024-07-24 20:57:13'),(19,2,NULL,2,NULL,'2024-07-24 20:54:00',NULL,NULL,'2024-07-24 20:57:59','2024-07-24 20:57:59');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,1,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2024-07-24 20:26:47','2024-07-24 20:26:47','2024-07-24 20:53:59','e9b2b966-53e6-47ed-b768-797d0fdca792'),(2,2,4,'Home','home',0,'site',NULL,'{section.name|raw}','site',NULL,1,1,'2024-07-24 20:54:09','2024-07-24 20:54:09',NULL,'3d6014bd-e860-4bb8-95b4-74590772d8e6');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2024-07-24 05:13:50','2024-07-24 05:13:50',NULL,'3f37c0a5-bb86-4164-8d5a-12b6d5ebfe11'),(2,'Homepage','2024-07-24 20:35:44','2024-07-24 20:35:44',NULL,'5774f43b-13c3-439f-ab6a-7d96e1417097');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayoutfields` VALUES (4,4,7,2,0,1,'2024-07-24 20:57:13','2024-07-24 20:57:13','31eff915-764b-4fcf-bc19-fc98092f67b5'),(5,4,7,6,0,2,'2024-07-24 20:57:13','2024-07-24 20:57:13','bdbc75e5-4c9b-4e8b-9097-b0e403619771');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2024-07-24 20:26:47','2024-07-24 20:26:47','2024-07-24 20:53:59','e2a5f059-d6d0-4882-ac56-ab68898a6ecf'),(2,'craft\\elements\\MatrixBlock','2024-07-24 20:45:32','2024-07-24 20:45:32','2024-07-24 20:48:04','4bccc574-6300-4bf5-a86f-27a71e7bde4c'),(3,'craft\\elements\\Asset','2024-07-24 20:52:03','2024-07-24 20:52:03',NULL,'f0e88ae8-8493-4b61-9355-4b5b3df242c3'),(4,'craft\\elements\\Entry','2024-07-24 20:54:09','2024-07-24 20:54:09',NULL,'b31d3068-00a9-47f9-835a-8a2e65dc6d4b');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouttabs` VALUES (2,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"76883d3a-d457-4a37-899c-7810a760affd\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"10edad22-1d5e-4594-94d9-3cd99593fd83\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"0ff5d922-5fd9-4527-aa9e-7d405382236d\"}]',1,'2024-07-24 20:27:09','2024-07-24 20:27:09','7eaa26f0-4566-49ed-a90f-cc87cd9eb0d7'),(4,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"58622b6c-296d-464c-89d5-7ffa75d3ce0c\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"71182614-e90a-4182-989d-8eb1cc6e9664\"}]',1,'2024-07-24 20:45:47','2024-07-24 20:45:47','3b4d0624-a58a-44c8-9469-87e886ed716a'),(5,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"e71addae-f249-4141-b5aa-3909eeeadb85\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-07-24 20:52:03','2024-07-24 20:52:03','da4aef78-f7ee-4845-831d-c0a142be84d1'),(7,4,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"6a11d743-375e-4dd3-ad04-5c7f4072d7ca\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"6d6839c5-7ed1-48bc-a8a5-3e0f52decb66\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"3c00910b-2e15-4588-8d72-72a4f8ca3506\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"66379d98-6ab3-4215-b358-2c433863225a\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"4cded286-e861-4ee6-9db4-fb2916e77e44\"}]',1,'2024-07-24 20:57:13','2024-07-24 20:57:13','dc19967d-3311-4acc-8e39-80b5d1765558');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (2,2,'Hero Title','heroTitle','global','ewyrbvdc',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-07-24 20:36:08','2024-07-24 20:36:08','3c00910b-2e15-4588-8d72-72a4f8ca3506'),(6,2,'Hero Image','heroImage','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:8c5d5fad-0196-4110-9f02-492e63407721\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:8c5d5fad-0196-4110-9f02-492e63407721\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:8c5d5fad-0196-4110-9f02-492e63407721\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2024-07-24 20:53:40','2024-07-24 20:53:40','4cded286-e861-4ee6-9db4-fb2916e77e44');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2024-07-24 20:46:24','2024-07-24 20:46:24','7321a3fb-78fa-49a4-84de-eed2ff39f1e5');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'4.10.6','4.5.3.0',0,'jvzjnqxbklmi','3@faxbbxqsfr','2024-07-24 05:13:50','2024-07-24 20:57:13','7a870946-2cb8-42bb-adad-4efbbc3f989b');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','8cf3bd7c-09b9-4ee8-8b1a-fcf018412379'),(2,'craft','m210121_145800_asset_indexing_changes','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','85362af2-ed93-4e94-82bf-5b3bad27a437'),(3,'craft','m210624_222934_drop_deprecated_tables','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','fc143c49-f46f-4637-b297-55060a67a41b'),(4,'craft','m210724_180756_rename_source_cols','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','d2654003-1c74-48b1-8458-1600710a13f2'),(5,'craft','m210809_124211_remove_superfluous_uids','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','e46e84f2-013a-4fd5-a517-b7afc2624c84'),(6,'craft','m210817_014201_universal_users','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','4ab83590-efec-4aaa-a10d-a44cfa31b073'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','4ca3da3a-a1ed-4f3e-a025-c9d1e190edce'),(8,'craft','m211115_135500_image_transformers','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','a5ced213-49de-4325-b5b0-664f7d308749'),(9,'craft','m211201_131000_filesystems','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','9ff3bfdf-4308-42fa-bfa7-6aee648f4a24'),(10,'craft','m220103_043103_tab_conditions','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','20a10190-5dec-4406-88f4-daf629549a4d'),(11,'craft','m220104_003433_asset_alt_text','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','3a176d23-be3a-4150-88a6-af11de038b1c'),(12,'craft','m220123_213619_update_permissions','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','40503c61-d117-4e1b-88f8-8326e685d05a'),(13,'craft','m220126_003432_addresses','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','1232de17-c846-4449-b8c6-d0ed15a3ae15'),(14,'craft','m220209_095604_add_indexes','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','d9c86774-813f-43fa-bbd4-b722770fbe63'),(15,'craft','m220213_015220_matrixblocks_owners_table','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','dfb636f8-aaf7-4919-a3d2-111f706452ec'),(16,'craft','m220214_000000_truncate_sessions','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','473ad6bf-70c7-40c0-8e55-bd2b0f7d5c04'),(17,'craft','m220222_122159_full_names','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','2e8e7a50-4fe1-41b3-b6d1-6fbb342c3574'),(18,'craft','m220223_180559_nullable_address_owner','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','a7d35f86-2f69-4867-9e4d-ad2bf20f9016'),(19,'craft','m220225_165000_transform_filesystems','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','e865d064-e0aa-4da0-873f-ecca8f21bd0f'),(20,'craft','m220309_152006_rename_field_layout_elements','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','60a0c247-e58e-4154-887c-a93e1cbc07c9'),(21,'craft','m220314_211928_field_layout_element_uids','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','2f48ae28-29ec-4fbb-b53d-6d30b52239ae'),(22,'craft','m220316_123800_transform_fs_subpath','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','62d566f8-1476-4d35-a906-fdc1b2d1cdc6'),(23,'craft','m220317_174250_release_all_jobs','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','75122e94-c391-4ed1-8621-3f8f383082ba'),(24,'craft','m220330_150000_add_site_gql_schema_components','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','ee143db6-59f9-43d7-83b3-a52b1aa18c36'),(25,'craft','m220413_024536_site_enabled_string','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','f035cb0e-193a-4335-8576-fde2ee38d8f6'),(26,'craft','m221027_160703_add_image_transform_fill','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','8aeb8a43-8c27-4c71-a614-c29a01926576'),(27,'craft','m221028_130548_add_canonical_id_index','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','9c50efde-b34a-4f35-9a58-ebb53d0610b2'),(28,'craft','m221118_003031_drop_element_fks','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','ed5e2b9a-e1af-4072-8356-e1677510804a'),(29,'craft','m230131_120713_asset_indexing_session_new_options','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','1b34107a-7141-40d6-934b-512b9f5fdb9c'),(30,'craft','m230226_013114_drop_plugin_license_columns','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','985f9723-a4a8-4a4e-88ae-7c6e941231fa'),(31,'craft','m230531_123004_add_entry_type_show_status_field','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','a97953ba-817c-44de-9d13-7a2adf925b03'),(32,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','b337ae13-0521-484f-b63f-800fcb093c7d'),(33,'craft','m230710_162700_element_activity','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','ea8473c8-a54c-4310-8ece-f6fcc30e0105'),(34,'craft','m230820_162023_fix_cache_id_type','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','73024f0c-ba23-4a3d-bb61-aacbe10cdc29'),(35,'craft','m230826_094050_fix_session_id_type','2024-07-24 05:13:50','2024-07-24 05:13:50','2024-07-24 05:13:50','b4b3eb30-bcc9-49dc-ab09-abc14f613102');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('dateModified','1721854633'),('email.fromEmail','\"guilleozan25@gmail.com\"'),('email.fromName','\"imagic\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elementCondition','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.autocapitalize','true'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.autocomplete','false'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.autocorrect','true'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.class','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.disabled','false'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.elementCondition','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.id','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.inputType','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.instructions','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.label','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.max','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.min','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.name','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.orientation','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.placeholder','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.readonly','false'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.requirable','false'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.size','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.step','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.tip','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.title','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.uid','\"6a11d743-375e-4dd3-ad04-5c7f4072d7ca\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.userCondition','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.warning','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.0.width','100'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.1.elementCondition','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.1.fieldUid','\"3c00910b-2e15-4588-8d72-72a4f8ca3506\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.1.instructions','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.1.label','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.1.required','false'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.1.tip','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.1.uid','\"6d6839c5-7ed1-48bc-a8a5-3e0f52decb66\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.1.userCondition','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.1.warning','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.1.width','100'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.2.elementCondition','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.2.fieldUid','\"4cded286-e861-4ee6-9db4-fb2916e77e44\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.2.instructions','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.2.label','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.2.required','false'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.2.tip','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.2.uid','\"66379d98-6ab3-4215-b358-2c433863225a\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.2.userCondition','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.2.warning','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.elements.2.width','100'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.name','\"Content\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.uid','\"dc19967d-3311-4acc-8e39-80b5d1765558\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.fieldLayouts.b31d3068-00a9-47f9-835a-8a2e65dc6d4b.tabs.0.userCondition','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.handle','\"home\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.hasTitleField','false'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.name','\"Home\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.section','\"452c67a5-89bf-4d1c-9073-f2231edb1d50\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.showStatusField','true'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.slugTranslationKeyFormat','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.slugTranslationMethod','\"site\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.sortOrder','1'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.titleFormat','\"{section.name|raw}\"'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.titleTranslationKeyFormat','null'),('entryTypes.3d6014bd-e860-4bb8-95b4-74590772d8e6.titleTranslationMethod','\"site\"'),('fieldGroups.3f37c0a5-bb86-4164-8d5a-12b6d5ebfe11.name','\"Common\"'),('fieldGroups.5774f43b-13c3-439f-ab6a-7d96e1417097.name','\"Homepage\"'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.columnSuffix','\"ewyrbvdc\"'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.contentColumnType','\"text\"'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.fieldGroup','\"5774f43b-13c3-439f-ab6a-7d96e1417097\"'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.handle','\"heroTitle\"'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.instructions','null'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.name','\"Hero Title\"'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.searchable','false'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.settings.byteLimit','null'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.settings.charLimit','null'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.settings.code','false'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.settings.columnType','null'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.settings.initialRows','4'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.settings.multiline','false'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.settings.placeholder','null'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.settings.uiMode','\"normal\"'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.translationKeyFormat','null'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.translationMethod','\"none\"'),('fields.3c00910b-2e15-4588-8d72-72a4f8ca3506.type','\"craft\\\\fields\\\\PlainText\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.columnSuffix','null'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.contentColumnType','\"string\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.fieldGroup','\"5774f43b-13c3-439f-ab6a-7d96e1417097\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.handle','\"heroImage\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.instructions','null'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.name','\"Hero Image\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.searchable','false'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.allowedKinds.0','\"image\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.allowSelfRelations','false'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.allowSubfolders','false'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.allowUploads','true'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.branchLimit','null'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.defaultUploadLocationSource','\"volume:8c5d5fad-0196-4110-9f02-492e63407721\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.defaultUploadLocationSubpath','null'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.localizeRelations','false'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.maintainHierarchy','false'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.maxRelations','null'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.minRelations','null'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.previewMode','\"full\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.restrictedDefaultUploadSubpath','null'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.restrictedLocationSource','\"volume:8c5d5fad-0196-4110-9f02-492e63407721\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.restrictedLocationSubpath','null'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.restrictFiles','true'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.restrictLocation','false'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.selectionLabel','null'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.showSiteMenu','false'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.showUnpermittedFiles','false'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.showUnpermittedVolumes','false'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.sources.0','\"volume:8c5d5fad-0196-4110-9f02-492e63407721\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.targetSiteId','null'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.validateRelatedElements','false'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.settings.viewMode','\"large\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.translationKeyFormat','null'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.translationMethod','\"site\"'),('fields.4cded286-e861-4ee6-9db4-fb2916e77e44.type','\"craft\\\\fields\\\\Assets\"'),('fs.cargas.hasUrls','true'),('fs.cargas.name','\"cargas\"'),('fs.cargas.settings.path','\"@webroot/cargas\"'),('fs.cargas.type','\"craft\\\\fs\\\\Local\"'),('fs.cargas.url','\"@web/cargas\"'),('graphql.schemas.7321a3fb-78fa-49a4-84de-eed2ff39f1e5.isPublic','true'),('graphql.schemas.7321a3fb-78fa-49a4-84de-eed2ff39f1e5.name','\"Public Schema\"'),('meta.__names__.3c00910b-2e15-4588-8d72-72a4f8ca3506','\"Hero Title\"'),('meta.__names__.3d6014bd-e860-4bb8-95b4-74590772d8e6','\"Home\"'),('meta.__names__.3f37c0a5-bb86-4164-8d5a-12b6d5ebfe11','\"Common\"'),('meta.__names__.452c67a5-89bf-4d1c-9073-f2231edb1d50','\"Home\"'),('meta.__names__.4cded286-e861-4ee6-9db4-fb2916e77e44','\"Hero Image\"'),('meta.__names__.5774f43b-13c3-439f-ab6a-7d96e1417097','\"Homepage\"'),('meta.__names__.5d2b1bee-effd-4089-8633-402e19744603','\"imagic\"'),('meta.__names__.7321a3fb-78fa-49a4-84de-eed2ff39f1e5','\"Public Schema\"'),('meta.__names__.8c5d5fad-0196-4110-9f02-492e63407721','\"cargas\"'),('meta.__names__.c83ba7f6-71e6-40bb-a837-274759f86ac1','\"imagic\"'),('sections.452c67a5-89bf-4d1c-9073-f2231edb1d50.defaultPlacement','\"end\"'),('sections.452c67a5-89bf-4d1c-9073-f2231edb1d50.enableVersioning','true'),('sections.452c67a5-89bf-4d1c-9073-f2231edb1d50.handle','\"home\"'),('sections.452c67a5-89bf-4d1c-9073-f2231edb1d50.name','\"Home\"'),('sections.452c67a5-89bf-4d1c-9073-f2231edb1d50.propagationMethod','\"all\"'),('sections.452c67a5-89bf-4d1c-9073-f2231edb1d50.siteSettings.5d2b1bee-effd-4089-8633-402e19744603.enabledByDefault','true'),('sections.452c67a5-89bf-4d1c-9073-f2231edb1d50.siteSettings.5d2b1bee-effd-4089-8633-402e19744603.hasUrls','true'),('sections.452c67a5-89bf-4d1c-9073-f2231edb1d50.siteSettings.5d2b1bee-effd-4089-8633-402e19744603.template','\"home/_entry\"'),('sections.452c67a5-89bf-4d1c-9073-f2231edb1d50.siteSettings.5d2b1bee-effd-4089-8633-402e19744603.uriFormat','\"home\"'),('sections.452c67a5-89bf-4d1c-9073-f2231edb1d50.type','\"single\"'),('siteGroups.c83ba7f6-71e6-40bb-a837-274759f86ac1.name','\"imagic\"'),('sites.5d2b1bee-effd-4089-8633-402e19744603.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.5d2b1bee-effd-4089-8633-402e19744603.handle','\"default\"'),('sites.5d2b1bee-effd-4089-8633-402e19744603.hasUrls','true'),('sites.5d2b1bee-effd-4089-8633-402e19744603.language','\"en-US\"'),('sites.5d2b1bee-effd-4089-8633-402e19744603.name','\"imagic\"'),('sites.5d2b1bee-effd-4089-8633-402e19744603.primary','true'),('sites.5d2b1bee-effd-4089-8633-402e19744603.siteGroup','\"c83ba7f6-71e6-40bb-a837-274759f86ac1\"'),('sites.5d2b1bee-effd-4089-8633-402e19744603.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"imagic\"'),('system.schemaVersion','\"4.5.3.0\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elementCondition','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.autocapitalize','true'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.autocomplete','false'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.autocorrect','true'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.class','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.disabled','false'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.elementCondition','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.id','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.inputType','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.instructions','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.label','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.max','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.min','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.name','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.orientation','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.placeholder','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.readonly','false'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.requirable','false'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.size','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.step','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.tip','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.title','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.uid','\"e71addae-f249-4141-b5aa-3909eeeadb85\"'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.userCondition','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.warning','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.elements.0.width','100'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.name','\"Content\"'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.uid','\"da4aef78-f7ee-4845-831d-c0a142be84d1\"'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fieldLayouts.f0e88ae8-8493-4b61-9355-4b5b3df242c3.tabs.0.userCondition','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.fs','\"cargas\"'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.handle','\"cargas\"'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.name','\"cargas\"'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.sortOrder','1'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.titleTranslationKeyFormat','null'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.titleTranslationMethod','\"site\"'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.transformFs','\"\"'),('volumes.8c5d5fad-0196-4110-9f02-492e63407721.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (2,6,6,NULL,18,1,'2024-07-24 20:57:59','2024-07-24 20:57:59','0b8a4d11-b082-4e29-bed2-3fd4e45ea845'),(3,6,19,NULL,18,1,'2024-07-24 20:57:59','2024-07-24 20:57:59','a0285f4a-0ce6-4a9e-a178-e36fcaab38cd');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,3,1,1,''),(2,6,1,1,NULL),(3,6,1,2,''),(4,6,1,3,NULL),(5,6,1,4,NULL),(6,6,1,5,'Applied “Draft 1”');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' guilleozan25 gmail com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'slug',0,1,' temp tabsfwacerswtwyzvqwotnjtdvmtfknjxncy '),(2,'title',0,1,''),(3,'slug',0,1,' testing entry '),(3,'title',0,1,' testing entry '),(5,'slug',0,1,' temp ggyieyvfaldcxfdxqttmmawgteqxukjjlqcq '),(5,'title',0,1,''),(6,'slug',0,1,' home '),(6,'title',0,1,' home '),(10,'alt',0,1,''),(10,'extension',0,1,' png '),(10,'filename',0,1,' 1 png '),(10,'kind',0,1,' image '),(10,'slug',0,1,''),(10,'title',0,1,' 1 '),(11,'alt',0,1,''),(11,'extension',0,1,' png '),(11,'filename',0,1,' 2 png '),(11,'kind',0,1,' image '),(11,'slug',0,1,''),(11,'title',0,1,' 2 '),(12,'alt',0,1,''),(12,'extension',0,1,' png '),(12,'filename',0,1,' 3 png '),(12,'kind',0,1,' image '),(12,'slug',0,1,''),(12,'title',0,1,' 3 '),(13,'alt',0,1,''),(13,'extension',0,1,' png '),(13,'filename',0,1,' 4 png '),(13,'kind',0,1,' image '),(13,'slug',0,1,''),(13,'title',0,1,' 4 '),(14,'alt',0,1,''),(14,'extension',0,1,' png '),(14,'filename',0,1,' 5 png '),(14,'kind',0,1,' image '),(14,'slug',0,1,''),(14,'title',0,1,' 5 '),(15,'alt',0,1,''),(15,'extension',0,1,' png '),(15,'filename',0,1,' 6 png '),(15,'kind',0,1,' image '),(15,'slug',0,1,''),(15,'title',0,1,' 6 '),(18,'alt',0,1,''),(18,'extension',0,1,' png '),(18,'filename',0,1,' 5 2024 07 24 205753 hmyk png '),(18,'kind',0,1,' image '),(18,'slug',0,1,''),(18,'title',0,1,' 5 ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'Slider','slider','channel',1,'all','end',NULL,'2024-07-24 20:26:47','2024-07-24 20:26:47','2024-07-24 20:53:59','1943851c-83ad-4d4a-b576-efe211c38855'),(2,NULL,'Home','home','single',1,'all','end',NULL,'2024-07-24 20:54:09','2024-07-24 20:54:09',NULL,'452c67a5-89bf-4d1c-9073-f2231edb1d50');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'slider/{slug}','slider/_entry',1,'2024-07-24 20:26:47','2024-07-24 20:26:47','6e8f7da7-ae7c-4303-a23a-7806c76e1672'),(2,2,1,1,'home','home/_entry',1,'2024-07-24 20:54:09','2024-07-24 20:54:09','e7dd2cdd-a4d4-4e29-a51d-4f8778755d82');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'imagic','2024-07-24 05:13:50','2024-07-24 05:13:50',NULL,'c83ba7f6-71e6-40bb-a837-274759f86ac1');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'true','imagic','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-07-24 05:13:50','2024-07-24 05:13:50',NULL,'5d2b1bee-effd-4089-8633-402e19744603');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\",\"locale\":null,\"weekStartDay\":\"1\",\"alwaysShowFocusRings\":false,\"useShapes\":false,\"underlineLinks\":false,\"notificationDuration\":\"5000\",\"showFieldHandles\":false,\"enableDebugToolbarForSite\":false,\"enableDebugToolbarForCp\":false,\"showExceptionView\":false,\"profileTemplates\":false}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin','',NULL,NULL,'guilleozan25@gmail.com','$2y$13$puBVNKW1S4Ue3lcDI5vx1e.ypAwfVLe8Md37Qa0F0R3pNOLuo/ehO','2024-07-24 20:21:03',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-07-24 21:59:02','2024-07-24 05:13:50','2024-07-24 21:59:02');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'cargas','','2024-07-24 20:52:03','2024-07-24 20:52:03','1d76b4f7-e782-488c-8aa9-e4120f492651'),(2,NULL,NULL,'Temporary filesystem',NULL,'2024-07-24 20:56:03','2024-07-24 20:56:03','7cecc9e7-f042-4abf-ac14-3d40dbe1ed85'),(3,2,NULL,'user_1','user_1/','2024-07-24 20:56:03','2024-07-24 20:56:03','bec4f4fc-8ba4-4d34-886b-5a1779ddc12b');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,3,'cargas','cargas','cargas','','','site',NULL,1,'2024-07-24 20:52:03','2024-07-24 20:52:03',NULL,'8c5d5fad-0196-4110-9f02-492e63407721');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2024-07-24 05:16:15','2024-07-24 05:16:15','d3146754-48af-416c-83a2-522eb0af9800'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-07-24 05:16:15','2024-07-24 05:16:15','586c572b-f4a3-4b05-9a0e-4cd460fc505c'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-07-24 05:16:15','2024-07-24 05:16:15','45a4ab01-e7e7-4dfc-90ee-5da59f0a4200'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2024-07-24 05:16:15','2024-07-24 05:16:15','d8f8948f-f135-46d6-b4e0-5db4f11b636e');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-24 22:00:56
